const CONFIG = {
  PORT: 3000,
  DB_URL: "mongodb://127.0.0.1:27017/second-hand-electronics",
  SECRET: "b747c899-986f-4f27-a6c5-07250fd1a0be",
};

module.exports = CONFIG;
